# info3300_p2
A dynamic data visualization with Kevin Lin and Marcus Boeck-Chenevier 
